#include "tic_tac_toe_manager.h"
#include "tic_tac_toe_3.h"
#include "tic_tac_toe_4.h"
#include <string>
#include <iostream>

using std::cout; using std::cin;


int main() 
{
	std::string first;
	char choice;
	TicTacToeManager manager;
	int game_choice;
	GameType type;
	TicTacToe* tic_tac_toe;

	do 
	{
		cout << "Tic tac toe 3 or 4: ";
		cin >> game_choice;

		if (game_choice == three)
		{
			tic_tac_toe = new TicTacToe3();
		}
		else 
		{
			tic_tac_toe = new TicTacToe4();
		}

		cout << "First player: ";
		cin >> first;
		tic_tac_toe->start_game(first);

		while (tic_tac_toe->game_over() == false) 
		{
			cin >> *tic_tac_toe;
			cout << *tic_tac_toe;
			cout << "\n\n";
		}

		cout<<"Winner: " << tic_tac_toe->get_winner();

		manager.save_game(*tic_tac_toe);

		cout << "play again";
		cin >> choice;

	} while (choice == 'y');

	cout<<manager;

	return 0;
}